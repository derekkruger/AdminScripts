PoshPAIG
========

PowerShell UI used for auditing and installing updates from WSUS to local and remote systems

![alt tag](https://github.com/proxb/PoshPAIG/blob/master/GitHub_Images/poshpaig_2_1_5.PNG)
